package questao1;

public interface Correr {

    void correr();

}
