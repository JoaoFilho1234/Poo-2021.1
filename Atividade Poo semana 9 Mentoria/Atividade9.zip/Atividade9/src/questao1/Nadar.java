package questao1;

public interface Nadar {

    void nadar();


}
