package questao1;

public interface Pedalar {

    void pedalar();

}
