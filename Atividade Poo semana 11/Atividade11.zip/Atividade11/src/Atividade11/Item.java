package Atividade11;

public interface Item {

    int getID();

    void setID(int id);

}
