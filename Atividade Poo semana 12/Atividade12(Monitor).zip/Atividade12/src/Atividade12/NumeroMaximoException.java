package Atividade12;

public class NumeroMaximoException extends Exception{

    public NumeroMaximoException(String mensagem) {
        super(mensagem);
    }

}
