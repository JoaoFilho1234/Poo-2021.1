package Atividade12;

public interface IPagamento {

    void formaPagamento(String forma);
    void valorTotal();
}
