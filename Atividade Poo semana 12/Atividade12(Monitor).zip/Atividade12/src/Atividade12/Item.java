package Atividade12;

public interface Item {

    int getID();

    void setID(int id);

}
