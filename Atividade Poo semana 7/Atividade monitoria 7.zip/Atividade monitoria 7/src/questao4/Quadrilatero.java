package questao4;

public class Quadrilatero extends Ponto2D {

    @Override
    public void Ponto2D(double x, double y) {
        super.Ponto2D(x, y);
    }
}
