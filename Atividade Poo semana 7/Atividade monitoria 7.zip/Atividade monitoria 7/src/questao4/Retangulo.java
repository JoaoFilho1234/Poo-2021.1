package questao4;

public class Retangulo extends Quadrilatero{
}
