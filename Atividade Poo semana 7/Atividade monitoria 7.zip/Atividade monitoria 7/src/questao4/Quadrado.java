package questao4;

public class Quadrado extends Quadrilatero{




}
