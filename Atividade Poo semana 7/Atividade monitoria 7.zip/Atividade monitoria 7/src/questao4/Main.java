package questao4;

public class Main {

    Quadrilatero quadrado = new Quadrado();


    Quadrilatero retangulo = new Retangulo();


    Quadrilatero trapezio = new Trapezio();


    Quadrilatero paralelogramo = new Paralelogramo();



}
