package questao4;

public class Paralelogramo extends Quadrilatero{
}
