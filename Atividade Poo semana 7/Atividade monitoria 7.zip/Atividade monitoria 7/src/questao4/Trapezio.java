package questao4;

public class Trapezio extends Quadrilatero{
}
